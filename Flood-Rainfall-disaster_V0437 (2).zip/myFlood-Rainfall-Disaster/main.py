from flask import Flask, render_template, abort, request, redirect, url_for, flash
import alerter
import driver
import Rainfall


app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about_team():
    return render_template("about-team.html")

@app.route("/contacts")
def contact():
    return render_template("contact.html")

@app.route("/services")
def service():
    return render_template("service.html")

@app.route('/floodHome')
def floodHome():
    res = alerter.alerting()
    for i in range(len(res)):
        res[i] = "Flood ALERT for " + res[i]
    return render_template("flood_entry.html", result=res)

@app.route('/floodResult',methods=['POST', 'GET'])
def floodResult():
    if request.method == 'POST':
        if len(request.form['DATE'])==0:
            return redirect(url_for('floodHome'))
        else:
            user_date=request.form['DATE']
            river=request.form['SEL']
            results_dict=driver.drive(river,user_date)
            # results_dict={'discharge': 1004.0, 'floodrunoff': 0.0, 'dailyrunoff': 0.71, 'weeklyrunoff': 4.56, 'predicted': 'Normal', 'actualflood': 'Normal'}
            print("-----------",type(results_dict),"----------")
            Table = []
            for key, value in results_dict.items():
                Table.append(value)
            return render_template('flood_result.html',result=Table)
    else:
        return "Under dev"

@app.route('/rainfallResult',methods=['POST','GET'])
def rainfallResult():
    if request.method == 'POST':
        if len(request.form['Year'])==0:
            flash("Please Enter Data!!")
            return redirect(url_for('rainfallHome'))
        else:
            year=request.form['Year']
            region=request.form['SEL']
            print("##3#######",year,"#####",region,"#############")
            mae,score=Rainfall.rainfall(year,region)
            return render_template('rain_result.html',Mae=mae,Score=score)
    else:
        return redirect(url_for('rainfallHome'))

@app.route('/rainfallHome')
def rainfallHome():
    return render_template('rain_entry.html')

@app.route('/refreshFlood')
def refreshFlood():
    alerter.water_level_predictor()
    return redirect(url_for("floodHome"))


if __name__ == '__main__':
    app.run(debug=True)