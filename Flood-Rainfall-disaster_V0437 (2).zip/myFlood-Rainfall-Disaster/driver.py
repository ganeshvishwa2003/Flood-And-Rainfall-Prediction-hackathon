import pandas as pd

def drive(river, date):
    storedData = pd.read_excel("data/" + river + ".xlsx")
    allDates = storedData['Date'].tolist()
    allDischarge = storedData['Discharge'].tolist()
    allFloodRun = storedData['flood runoff'].tolist()
    allDailyRun = storedData['daily runoff'].tolist()
    allWeeklyRun = storedData['weekly runoff'].tolist()
    allFlood     = storedData['Flood'].tolist()
    usrDateIndex = None
    temp_i = 0
    for dates in allDates:
        if date in str(dates):
            usrDateIndex = temp_i
            break
        temp_i += 1
    floodLevel = ""
    usrDateIndex = temp_i
    if allFlood[usrDateIndex] == 0:
        floodLevel = "Normal"
    else:
        floodLevel = "High"
    results = {
        "discharge": allDischarge[usrDateIndex],
        "floodrunoff": allFloodRun[usrDateIndex],
        "dailyrunoff": allDailyRun[usrDateIndex],
        "weeklyrunoff": allWeeklyRun[usrDateIndex],
        "meanabsoluteerror": 0,
        "predicted" : floodLevel,
        "actualflood": floodLevel
    }
    return results